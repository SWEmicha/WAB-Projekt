<?php
    
class SqlAdapter
{
    
    public $db;
    private $dsn = 'mysql:host=localhost;dbname=lost_property';
    private $username = 'root';
    private $password = 'admin123';
    
    public function __construct()
    {
        $options = array(
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        );        
        $this->db= new PDO($this->dsn, $this->username, $this->password, $options);
    }
}