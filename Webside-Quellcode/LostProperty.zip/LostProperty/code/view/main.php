<?php
require_once('code/interfaces/viewInterface.php');
require_once('abstractView.php');

class View extends abstractView implements ViewInterface
{
    const DEFAULT_TEMPLATE = 'main.phtml';
    
    public function toHtml()
    {
        return $this->_loadTemplate(self::DEFAULT_TEMPLATE);
    }
}