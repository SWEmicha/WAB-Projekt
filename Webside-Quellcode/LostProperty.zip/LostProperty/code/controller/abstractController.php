<?php
class abstractController 
{
    const VIEW_DIR = 'code/view/';
    
    protected function _renderLayout($viewName)
    {
        include_once(self::VIEW_DIR . $viewName);
        $view = new View($this->model);
        echo $view->toHtml();
    }
    
    public function execute($action)
    {
        call_user_func(array($this, $action));
    } 
}
