<?php
require_once('code/interfaces/controllerInterface.php');
require_once('code/controller/abstractController.php');

class Controller extends abstractController implements ControllerInterface
{
    private $request = null;  
    private $viewName = ''; 
    protected $model = null;
    protected $template = null;
        
    const MODEL_PATH = 'code/model/LostProperty.php';
    const DEFAULT_VIEW_NAME = 'property/list.php';
    
    
    public function __construct($request)
    {
        require_once(self::MODEL_PATH);
        
        $this->request = $request;  
        $this->setViewName(self::DEFAULT_VIEW_NAME);
        $this->model = new LostProperty();
    } 
    
    public function getViewName()
    {
        return $this->viewName;
    }
    
    public function setViewName($template)
    {
        $this->viewName = $template;
    }
    
    public function renderLayout()
    {
        $viewName = $this->getViewName();
        parent::_renderLayout($viewName);
    }
    
    public function delete()
    {
        $request = $this->request;
        var_dump($request);
        $id = $request['id'];
        $this->model->delete($id);
    }
    
    public function view()
    {
        $this->setViewName('property/view.php');
        $request = $this->request;
        if(isset($request['id'])){
            $id = $request['id'];
            $this->model->load($id);
        }
    }
    
    public function create()
    {
        $this->setViewName('property/new.php');
    }
    
    public function save()
    {
        $request = $this->request;
        foreach ($request as $key => $value) {
            if($key != "path"){
                $data[$key] = $value;
            }
        }
        $this->model->insert($data);
    }
    
}
