<?php
interface ViewInterface
{
    public function toHtml();
}