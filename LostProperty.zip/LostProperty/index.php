<?php
const CONTROLLER_DIR = 'code/controller/';
const DEFAULT_CONTROLLER = 'default';
const MAIN_CONTROLLER = 'main';

error_reporting(E_ALL ^ (E_WARNING | E_NOTICE));

$request = array_merge($_GET, $_POST);
$controllerData = null;

if(isset($request['path'])){
	$pathParts = explode('/', $request['path']);
	foreach ($pathParts as $index => $part) {
		switch($index){
			case 0: 
				$controllerData['controller']  = $part;
				break; 
			case 1:
				$controllerData['action']  = $part; 
				break;
			default:
				
		}
	}
} else{
	$controllerData['controller'] = MAIN_CONTROLLER;
}

$controllerFileName = $controllerData['controller'] . 'Controller.php';

if(include_once(CONTROLLER_DIR . $controllerFileName)){
	$controller = new Controller($request);

	if(isset($controllerData['action'])){
		$action = $controllerData['action'];
		$controller->execute($action);
	}
} else {
    include_once(CONTROLLER_DIR . DEFAULT_CONTROLLER .'Controller.php');
    $controller = new Controller($request);
}

$controller->renderLayout();