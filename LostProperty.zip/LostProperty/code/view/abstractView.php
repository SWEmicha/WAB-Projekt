<?php

class abstractView
{
    
    const TEMPLATE_DIR = 'design/html/';
    
    protected function _loadTemplate($template)
    {
        $file = self::TEMPLATE_DIR . $template;
        $exists = file_exists($file);  
           if ($exists){  
            // Der Output des Scripts wird n einen Buffer gespeichert, d.h.  
            // nicht gleich ausgegeben.  
            ob_start();  
                  
            // Das Template-File wird eingebunden und dessen Ausgabe in   
            // $output gespeichert. 
            include_once($file);
            $output = ob_get_contents();  
            ob_end_clean();  
              
            // Output zurückgeben.  
            return $output;  
        }
    } 
}
