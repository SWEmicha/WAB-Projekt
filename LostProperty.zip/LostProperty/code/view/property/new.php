<?php
require_once('code/interfaces/viewInterface.php');
require_once('code/view/abstractView.php');

class View extends abstractView implements ViewInterface
{
    const DEFAULT_TEMPLATE = 'property/new.phtml';
    
    protected $model = null;
    
    public function __construct($model)
    {
        $this->model = $model;
    }
    
    public function toHtml()
    {
        return $this->_loadTemplate(self::DEFAULT_TEMPLATE);
    }
    
}
