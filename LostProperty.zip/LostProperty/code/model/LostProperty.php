<?php
    
include_once('code/model/SqlAdapter.php');
class LostProperty 
{
    public $sqlAdapter;
    
    protected $data = array();
    
    protected $collection = null;
    
    public function __construct()
    {
        $this->sqlAdapter = new SqlAdapter();
        $this->setCollection();
    }  
    
    public function load($id)
    {
        $db = $this->sqlAdapter->db;
        $query = $db->prepare('SELECT * FROM properties WHERE entity_id = :id');
        $query->bindValue(':id', $id); 
        $query->execute();
        $result = $query->fetch();
        $this->data = $result;
    }
    
    public function delete($id)
    {
        $db = $this->sqlAdapter->db;
        $query = $db->prepare('DELETE FROM properties WHERE entity_id = :id');
        $query->bindValue(':id', $id); 
        $query->execute();
        $this->setCollection();
    }
            
    public function insert($data)
    {
        $db = $this->sqlAdapter->db;
        foreach($data as $key => $value){
            $keys .= $key . ',';
            $values .= "'$value',";
        }
        $keys = substr($keys, 0, -1);
        $values = substr($values, 0, -1);
        $statement = ("INSERT INTO properties ($keys) VALUES ($values)");
        $query = $db->prepare($statement);
        $query->execute();
        header('Location: http://localhost/LostProperty/Property');
    }
    
    protected function setCollection()
    {
        $db = $this->sqlAdapter->db;
        $query = $db->prepare('SELECT * FROM properties');
        $query->execute();
        
        $result = $query->fetchAll();
        $this->collection = $result;
    }
    
    public function getCollection()
    {
        return $this->collection;
    }
    
    public function getData($key = null)
    {
        $data = $this->data;
        if($key == null){
            return $data;
        }
        if(isset($data[$key])){
            return $data[$key];
        }
    }
   
}
