<?php
interface ControllerInterface
{
	public function execute($action);
	
	public function renderLayout();
	
	public function getViewName();
	
	public function setViewName($template);
	
}
