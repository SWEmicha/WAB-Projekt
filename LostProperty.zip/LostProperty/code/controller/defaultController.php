<?php
require_once('code/interfaces/controllerInterface.php');
require_once('code/controller/abstractController.php');

class Controller extends abstractController implements ControllerInterface
{  
  
    private $request = null;  
    private $viewName = '';  
  
	const DEFAULT_VIEW_NAME = 'main.php';
    /** 
     * 
     * @param Array $request Array aus $_GET & $_POST. 
     */  
    public function __construct($request)
    {
        $this->request = $request;  
		$this->setViewName(self::DEFAULT_VIEW_NAME);
    } 

	public function setViewName($viewName)
	{
		$this->viewName = $viewName;
	}

	public function getViewName()
	{
		return $this->viewName;
	}
    
    public function getRequest()
    {
        return $this->request;
    }

    public function renderLayout()
    {
        $viewName = $this->getViewName();
        parent::_renderLayout($viewName);
    }
    
}  