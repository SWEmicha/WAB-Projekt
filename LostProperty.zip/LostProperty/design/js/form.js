jQuery('#new_property_form').on('submit', function(event){
	keyObject = jQuery(event.target).find('#delete_key')[0];
	key = CryptoJS.MD5(keyObject.value).toString();
	jQuery(keyObject)[0].value = key;
});

jQuery('#delete_property_form').on('submit', function(event){
	var keyValue = prompt("Bitte geben Sie das von Ihnen gesetzten Passwort zum Löschen an.");
	inputKey = CryptoJS.MD5(keyValue).toString();
	deleteKeyObject = jQuery(event.target).find('#delete_key')[0];
	keystring = deleteKeyObject.value;
	res = keystring.split("-"); 
	key = res[0];
	id = res[1];
	console.log(inputKey);
	console.log(key);
	data = {
		id: id
	};
	if(inputKey == key){
		jQuery.post('http://localhost/LostProperty/Property/delete', data);
	} else {
		event.preventDefault();
		alert("Passwort inkorrekt");
	}
	
});
